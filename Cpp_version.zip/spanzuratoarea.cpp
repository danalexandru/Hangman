#include "spanzuratoarea.h"
spanzuratoarea::spanzuratoarea(int x):ver(x)
{
    viz = NULL;
    // --------- deschidere fisier ---------
    ifstream fin;
    if (ver == 1) fin.open("easy.txt");
    else if (ver == 2) fin.open("medium.txt");
    else fin.open("hard.txt");
    // --------- nr total linii in fisier ---------
    while (!fin.eof())
    {
        getline(fin, cuvant);
        nlines++;
    }
    // --------- o linie random ---------
    srand(time(NULL));
    line = rand() % (nlines - 1) + 1;
    fin.close();
    // --------- cuvantul de pe linia line ---------
    if (ver == 1) fin.open("easy.txt");
    else if (ver == 2) fin.open("medium.txt");
    else fin.open("hard.txt");
    for (int i = 0;i < line; i++)
        getline(fin, cuvant);
    viz = new int[cuvant.size()];
    // --------- vector ---------
    for (int i=0;i<cuvant.size();i++)
        viz[i] = 0;
    int i = rand() % cuvant.size();
    viz[i] = 1;
    i = rand() % cuvant.size();
    viz[i] = 1;
    fin.close();

}
spanzuratoarea::~spanzuratoarea()
{
    delete [] viz;
}
void spanzuratoarea::hangman()
{
    cout<<"WORD:";
    for (int i = 0;i < cuvant.size();i++)
        if (viz[i] == 0) cout<<"_";
        else cout<<cuvant[i];
        cout<<endl<<"error: "<<error<<endl;
    if (ver == 1)
    {
        if (error == 0)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 1)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                 ( ) "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 2)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                 ( ) "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 3)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                 ( ) "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                --| "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 4)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                      "<<endl;
            cout<<"|                      "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 5)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                 _|_    "<<endl;
            cout<<"|                 |     "<<endl;
            cout<<"|                 |     "<<endl;
        }
        if (error == 6)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                 _|_    "<<endl;
            cout<<"|                 | |  "<<endl;
            cout<<"|                 | |  "<<endl;
        }
    }
    if (ver == 2)
    {
        if (error == 0)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 1)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                 ( ) "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 2)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                 ( ) "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 3)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                      "<<endl;
            cout<<"|                      "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 4)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                 _|_    "<<endl;
            cout<<"|                 | |  "<<endl;
            cout<<"|                 | |  "<<endl;
        }
    }
    if (ver == 3)
    {
        if (error == 0)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
        }
        if (error == 1)
        {
            cout<<"____________________ "<<endl;
            cout<<"|                  | "<<endl;
            cout<<"|                 ( ) "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                    "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 2)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                      "<<endl;
            cout<<"|                      "<<endl;
            cout<<"|                      "<<endl;
        }
        if (error == 3)
        {
            cout<<"____________________   "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                 ( )  "<<endl;
            cout<<"|                  |   "<<endl;
            cout<<"|                --|-- "<<endl;
            cout<<"|                 _|_    "<<endl;
            cout<<"|                 | |  "<<endl;
            cout<<"|                 | |  "<<endl;
        }
    }
}
int spanzuratoarea::get_suma()
{
    int s = 0;
    for (int i=0;i<cuvant.size();i++)
        s += viz[i];
    return s;
}
void spanzuratoarea::joc()
{
    cout<<endl;
    hangman();
    cout<<endl;
    char a;
    cout<<"Key: ";
    a = getch();
    system("cls");
    int este = 0;
    for (int i = 0;i < cuvant.size();i++)
        if (cuvant[i] == a) {
                viz[i] = 1;
        este = 1;
        }
        if (este == 0) error++;
        ifstream fin("score.bin", ios::binary);
        fin>>score;
        fin.close();
    cout<<endl;
    if (ver == 1 && error == 6)
    {
        score--;
        cout<<"You have lost! The word was "<<cuvant<<"."<<endl;
        cout<<"Score: "<<score<<";"<<endl;
    }
    else if (ver == 2 && error == 4)
    {
        score -= 5;
        cout<<"You have lost! The word was "<<cuvant<<"."<<endl;
        cout<<"Score: "<<score<<";"<<endl;
    }
    else if (ver == 3 && error == 3)
    {
        score -= 10;
        cout<<"You have lost! The word was "<<cuvant<<"."<<endl;
        cout<<"Score: "<<score<<";"<<endl;
    }
    else if (cuvant.size() == get_suma())
    {
        if (ver == 1) score ++;
        else if (ver == 2) score += 5;
        else score += 10;
        cout<<"You habe won! Congratulations!"<<endl;
        cout<<"Score: "<<score<<";"<<endl;
    }
    else joc();
    ofstream fout("score.bin", ios::binary);
    fout<<score;
    fout.close();
}
