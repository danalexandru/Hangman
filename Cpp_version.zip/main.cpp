#include "spanzuratoarea.h"

int start()
{
    char a;
    a = getch();
    cout<<endl;
    while (a != 'y' &&  a != 'Y' && a != 'N' && a != 'n')
    {
        cout<<"You have introduced an odd character! Please try again!"<<endl;
        cout<<"Do you want to play(Y/N) ";
        a = getch();
        cout<<endl;
    }
    if (a == 'N' || a == 'n') return 0;
    else {
            system("cls");
            cout<<"Choose a level of difficulty: "<<endl;
            cout<<"* EASY level: Press E;"<<endl;
            cout<<"* MEDIUM level: Press M;"<<endl;
            cout<<"* HARD level: Press H;"<<endl;
            cout<<"*Or you can cancel by pressing X;"<<endl;
            cout<<endl<<"Key: ";
            char a;
            a = getch();
            if (a == 'x' || a == 'X') start();
            if (a == 'e' || a == 'E' ) return 1;
            else if (a == 'm' || a == 'M') return 2;
            else if (a == 'h' || a == 'H') return 3;
            }
            return 0;
}

int main()
{
    cout<<"Welcome to Hangman 2.0! This version was created using classes!"<<endl;
    cout<<"Do you want to play(Y/N) ";
    int a = start();
    system("cls");
    while (a != 0)
    {
        cout<<endl;
        spanzuratoarea x(a);
        x.joc();
        cout<<endl<<"Do you want to play again?(Y/N)";
        a = start();
    }
    return 0;
}

