
#include<iostream>
#include<fstream>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<time.h>
using namespace std;

class spanzuratoarea{
    string cuvant;
    int n, *viz, ver;
    int line, nlines = 0;
    int error = 0, score;
public:
    spanzuratoarea(int);
    ~spanzuratoarea();
    void joc();
    int get_suma();
    void hangman();
};
