#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<time.h>
int start()
{
    char a;
    a = getch();
    while (a != 'n' && a != 'N' && a !='y' && a != 'Y'){
        printf("\nYou introduced an odd character. Please try again!\n");
        fflush(stdin);
        printf("Key: ");
        a = getch();
    }
    if (a == 'n' || a == 'N')
        {
            system("cls");
            printf("Ok. Have a nice day.\n");
            return 0;
        }
        else{
            system("cls");
            printf("Great! What level of dificulty?\n");
            printf("You can choose between:\n");
            printf("*EASY level (Press E);\n");
            printf("*MEDIUM level (Press M);\n");
            printf("*HARD level (Press H);\n");
            printf("\nOr you can cancel by pressing X;\n");
            printf("Key: ");
            fflush(stdin);
            a = getch();
            if (a == 'x' || a == 'X') start();
            else {
                if (a == 'e' || a == 'E') return 1;
                if (a == 'm' || a == 'M') return 2;
                if (a == 'h' || a == 'H') return 3;
            }
        }
}
int countlines(int ver)
{
    FILE *f;
    if (ver == 1) f = fopen("easy.txt", "rt");
    else if (ver == 2) f = fopen("medium.txt", "rt");
    else f = fopen("hard.txt", "rt");
    char ch;
    int lines = 0;
    if (f == NULL) return 10;
    while(!feof(f))
    {
        fflush(stdin);
        ch = fgetc(f);
        if(ch == '\n')
            lines++;
    }
    fclose(f);
    return lines;
}
int nr_characters(int ver, int i)
{
    FILE *f;
    if (ver == 1) f = fopen("easy.txt", "rt");
    else if (ver == 2) f = fopen("medium.txt", "rt");
    else if (ver == 3) f = fopen("hard.txt", "rt");
    int n = 0, j = 0;
    int ch = fgetc(f);
    while (j != i)
    {
        fflush(stdin);
        ch = fgetc(f);
        if (ch == '\n')
            j++;
    }
    ch = fgetc(f);
    while (ch != '\n')
    {
        fflush(stdin);
        ch = fgetc(f);
        n++;
    }
    fclose(f);
    return n;
}
char *word(int ver, int i)
{
    FILE *f;
    char ch;
    if (ver == 1) f = fopen("easy.txt", "rt");
    else if (ver == 2) f = fopen("medium.txt", "rt");
    else if (ver == 3) f = fopen("hard.txt", "rt");
    char *a;
    a = (char*)malloc(12*sizeof(char));
    int j = 0;
    while (j != i)
    {
        fflush(stdin);
        ch = fgetc(f);
        if (ch == '\n')
            j++;
    }
        fscanf(f, "%s", a);
    return a;
}
void empty_hangman()
{
    printf("____________________\n");
    printf("|                  |\n");
    printf("|                   \n");
    printf("|                   \n");
    printf("|                   \n");
    printf("|                   \n");
    printf("|                   \n");
    printf("|                   \n");
}
void generate_hangman(char *a, int n)
{
    int i, j, k, *poz, *viz;
    i = rand() % 3;
    while (i == 0) i = rand() % 3;
    poz = (int*)malloc(i*sizeof(int));
    viz = (int*)malloc(n*sizeof(int));
    for (j=0;j<n;j++)
        viz[j] = 0;
    for (j=0;j<i;j++)
    {
            poz[j] = rand() % n;
            while (poz[j] == 0 || (j > 0 && poz[j] == poz[j-1])) poz[j] = rand() % n;
            viz[j] = 1;
    }
    char ch;
    for (j=0;j<i;j++)
    {
        ch = a[poz[j]];
        for (k=0;k<n;k++)
            if (ch == a[k]) viz[k] = 1;
    }
    for (j=1;j<n;j++)
        if (a[j] == a[0]) viz[j] = 1;
    system("cls");
    FILE *f = fopen("position.bin", "wb");
    fflush(stdin);
    fwrite(&viz, sizeof(int), 1, f);
    fclose(f);
    printf("Hangman: ");
    for (j=0;j<n;j++)
    {
        if (viz[j] == 1) printf("%c", a[j]);
        else printf("_");
    }
}
void verify(char *a, int n, int ver, int error, int score)
{
    FILE *f = fopen("position.bin", "rb");
    int i, *viz;
    fread(&viz, sizeof(int), 1, f);
    fclose(f);
    system("cls");
    printf("Hangman: ");
    for (i=0;i<n;i++)
    {
        if (viz[i] == 1) printf("%c", a[i]);
        else printf("_");
    }
    printf("\n");
    if (ver == 1)
    {
        if (error == 0)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 1)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                 ( )\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 2)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                 ( )\n");
            printf("|                  |\n");
            printf("|                  |\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 3)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                 ( )\n");
            printf("|                  |\n");
            printf("|                --|\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 4)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                     \n");
            printf("|                     \n");
            printf("|                     \n");
        }
        if (error == 5)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                 _|_   \n");
            printf("|                 |    \n");
            printf("|                 |    \n");
        }
        if (error == 6)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                 _|_   \n");
            printf("|                 | | \n");
            printf("|                 | | \n");
        }
    }
    if (ver == 2)
    {
        if (error == 0)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 1)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                 ( )\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 2)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                 ( )\n");
            printf("|                  |\n");
            printf("|                  |\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 3)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                     \n");
            printf("|                     \n");
            printf("|                     \n");
        }
        if (error == 4)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                 _|_   \n");
            printf("|                 | | \n");
            printf("|                 | | \n");
        }
    }
    if (ver == 3)
    {
        if (error == 0)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
        }
        if (error == 1)
        {
            printf("____________________\n");
            printf("|                  |\n");
            printf("|                 ( )\n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                   \n");
            printf("|                     \n");
        }
        if (error == 2)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                     \n");
            printf("|                     \n");
            printf("|                     \n");
        }
        if (error == 3)
        {
            printf("____________________  \n");
            printf("|                  |  \n");
            printf("|                 ( ) \n");
            printf("|                  |  \n");
            printf("|                --|--\n");
            printf("|                 _|_   \n");
            printf("|                 | | \n");
            printf("|                 | | \n");
        }
    }
    printf("\nScore: %d", score);
}
int answer(char *a, int n, int ver, int error, int score)
{
    char ch;
    int e = 0, *viz, i;
    FILE *f = fopen("position.bin", "rb");
    fflush(stdin);
    fread(&viz, sizeof(int), 1, f);
    fclose(f);
    printf("Key: "); ch = getch();
    for (i=0;i<n;i++)
        if (a[i] == ch && viz[i] == 0) {
                viz[i] = 1;
                e = 1;
        }
    if (e == 0) error++;
    verify(a, n, ver, error, score);
    return error;
}
void version(int x)
{
    int m = countlines(x);
    int i, error = 0, emax, *viz, sum, score;
    srand(time(NULL));
    i = rand() % m;
    int n = nr_characters(x, i);
    char *a;
    a = word(x, i);
    n = strlen(a);
    a[n] = NULL;
    realloc(a, (n+1)*sizeof(char));
    generate_hangman(a, n);
    printf("\n");
    empty_hangman();
    FILE *f = fopen("position.bin", "rb");
    fflush(stdin);
    fread(&viz, sizeof(int), 1, f);
    fclose(f);
    f = fopen("score.bin", "rb");
    fread(&score, sizeof(int), 1, f);
    fclose(f);
    printf("\nScore: %d", score);
    if (x == 1) emax = 6;
    else if (x == 2) emax = 4;
    else if (x == 3) emax = 3;
    sum = 0;
    for (i=0;i<n;i++)
        sum = sum + viz[i];
    while (sum <= n || error <= emax)
    {
        printf("\nerror: %d\n", error);
        if (error == emax){
            if (x == 1) score -= 1;
            if (x == 2) score -= 5;
            if (x == 3) score -= 10;

            system("cls");
            printf("You lose!\n");
            printf("The answer was %s.\n", a);
            printf("Score: %d\n", score);

            f = fopen("score.bin", "wb");
            fwrite(&score, sizeof(int), 1, f);
            fclose(f);
            break;
            }
        else if (sum == n ) {
                if (x == 1) score += 1;
                if (x == 2) score += 5;
                if (x == 3) score += 10;
                printf("\nYou win! Congratulations!\n");
                printf("Score: %d\n", score);
                f = fopen("score.bin", "wb");
                fwrite(&score, sizeof(int), 1, f);
                fclose(f);
                break;
        }
    else error = answer(a, n, x, error, score);
    sum = 0;
    for (i=0;i<n;i++)
        sum = sum + viz[i];
    }
    free(a);
    free(viz);
}
int main()
{
    printf("Welcome to hungman 1.0!\n");
    printf("Do you want to play?(Y/N)");
    int a = start();
    if (a == 0) return 0;
    else while (a != 0){
        version(a);
        printf("Do you want to play again?");
        a = start();
    }
}
